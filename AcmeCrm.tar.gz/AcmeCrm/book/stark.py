



from .models import *

from stark.service.sites import site,ModelStark


class BookConfig(ModelStark):
    list_display = ["title","price","publisher","authors"]  # 列表时，定制可以显示的列
    list_display_links = ["title"]         # 列表时，定制列可以点击跳转
    search_fields = ["title","price"]      # 列表时，模糊搜索的功能
    list_filter = ["publisher","authors"]  # 定制右侧快速查询

site.register(Book,BookConfig)
site.register(Publish)
site.register(Author)


