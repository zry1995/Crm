
from django.test import TestCase

# Create your tests here.

l1 = [1,0,-3,9,6,5,-4,10,-7,4]



# def mopap(args):
#     print(len(args))
#     for i in range(len(args)-1):
#         for k,v in enumerate(args):
#             print(k,v)
#             if k+1 <= len(args)-1:
#                 if v > args[k+1]:
#                    args[k],args[k+1] = args[k+1],v
#     return args
#
#
# print(mopap(l1))


#
# def bubb(x):
#     for i in range(len(x) -1):
#         for j in range(len(x) -i -1):
#             if x[j] > x[j+1]:
#                 x[j],x[j+1] = x[j+1],x[j]
#
# l1 = [1,0,-3,9,0,5,-4,10,-7,4]
#
# bubb(l1)
# print(l1)


#快排



def good(x):
    print(x)



ret  =good(3)
